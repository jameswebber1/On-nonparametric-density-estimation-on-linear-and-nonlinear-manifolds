% Reconstructs a 2-D patch of density 1 embedded in 3-D
% plots results and gives errors

close all

options=[];
options.RegParam='gcv';
options.inSolver='lsqr';
options.nonnegativity='on';
options.stopGCV='GCVvalues';

[X,Y]=meshgrid(0:100);
[X1,Y1]=meshgrid(0:100);
X1=reshape(X1,length(0:100)^2,1);
Y1=reshape(Y1,length(0:100)^2,1);

gm = gmdistribution(mu,sigma);
PD=pdf(gm,[X1,Y1]);
PD=reshape(PD,101,101);
PD=PD./sum(sum(PD));
%figure, imagesc(PD)
z1=kappa/2*(B(:,1).^2+B(:,2).^2);
D=[B,z1];
ind=(B(:,1)-pcrd(1)).^2+(B(:,2)-pcrd(2)).^2+(z1-pcrd(3)).^2<=rad.^2;
figure, scatter3(B(:,1),-B(:,2),z1,[],ind,'.')
xlim([-50,50])
ylim([-50,50])
axis equal
xlabel('x')
ylabel('y')
zlabel('z')
title('Density 1 embedded in three dimensions')

m=sum(ind);
K=round(m*0.2);
[coeff1,score1,latent1]=pca(D(ind,:));

figure, plot(latent1,'-.r*')
xlabel('Component')
ylabel('Eigenvalue')
title('Eigenvalue plot')

for l=1:3
    if sum(latent1(1:l))/sum(latent1)>0.9
        break
    end
end
if l==1
    l=2;
end
ddim=score1(:,1:l);
%ddim=ddim*coeff1(1:2,1:2);
vv=sqrt(sum(ddim.^2,2));
vv=max(vv);
vv=ddim.*45/vv;
ddim=vv+[50,50];
lbl=ones(size(ddim,1),1);
figure, scatter(ddim(:,1),ddim(:,2),[],lbl,'.')
xlim([0,100])
ylim([0,100])
xlabel('x')
ylabel('y')
title('Manifold patch in PC space')

b=CRadond(r,X1,Y1,ddim,lbl);
I=IRhtv(R,b,options);
I=reshape(I,101,101);
I=I(101:-1:1,:);
I=I./sum(abs(I(:)));
figure, imagesc(reshape(I,101,101))
colorbar;
xlabel('x')
ylabel('y')
title('Reconstruction of density patch')

ans2=interp2(X,Y,PD(101:-1:1,:),B(ind,1)+50,B(ind,2)+50,'nearest');
ans2=ans2./sum(abs(ans2));
ans1=interp2(X,Y,I(101:-1:1,:),ddim(:,1),ddim(:,2),'nearest');
ans1=ans1./sum(abs(ans1));

%figure, scatter(ddim(:,1),ddim(:,2),[],ans1,'.')
%xlim([0,100])
%ylim([0,100])
%figure, scatter(ddim(:,1),ddim(:,2),[],ans2,'.')
%xlim([0,100])
%ylim([0,100])

err=norm(ans2-ans1)./norm(ans2)