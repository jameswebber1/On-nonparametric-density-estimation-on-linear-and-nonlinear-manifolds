function [R] = HRadon(s,theta,N)
% Generate half space Radon operator

% inputs:
% 1) s (1Xn vector) is set of perpendicular distances of the half space
% boundary to the origin, e.g., s=-50:50
% 2) theta (1Xm vector) is set of rotation angles for Radon projections, e.g.,
% theta=0:pi/180:pi
% 3) N (positive integer) is grid size, e.g., N=100

% outputs
% 1) R is sparse matrix (size (nXm)XN^2) which is the discrete form of the
% half space Radon transform

[X,Y]=meshgrid(0:N);
X=X-N/2;
Y=Y-N/2;
R=[];
n=length(s);
m=length(theta);
for j=1:m
    M=zeros(n,(N+1)^2);
    t1=cos(theta(j));
    t2=sin(theta(j));
for i=1:n
    v=(X.*t1+Y.*t2)>s(i); 
    v=reshape(v,1,(N+1)^2);
    M(i,v)=1;
end
M=sparse(M);
R=[R;M];
end



end

