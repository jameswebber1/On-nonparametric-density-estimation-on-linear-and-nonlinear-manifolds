function b = HRadond(s,theta,N,B,lbl)
% Generate half space Radon transform data from point cloud

% inputs:
% 1) s (1Xn vector) is set of perpendicular distances of the half space
% boundary to the origin, e.g., s=-50:50
% 2) theta (1Xm vector) is set of rotation angles for Radon projections, e.g.,
% theta=0:pi/180:pi
% 3) N is grid size for [0,N]^2 2-D grid, e.g., N=100
% 4) B (nsamples X ndimensions matrix) is point cloud
% 5) lbl (nsamples X 1 vector) is vector of labels corresponding to each sample of B

% outputs
% 1) b is half space Radon transform data

n=length(s);
m=length(theta);
u1=B(:,1);
u2=B(:,2);
u1=u1-N/2;
u2=u2-N/2;
N1=length(u1);
b=zeros(n*m,1);
for j=1:m
    j1=(j-1)*n;
    t1=cos(theta(j));
    t2=sin(theta(j));
for i=1:n
    v=(u1.*t1+u2.*t2)>s(i)+0.5;
    v=reshape(v,1,N1);
    v=v*lbl;
    b(j1+i)=v;
end
end
b(isnan(b))=0;


end

