% create density 1 with sample size m
% density generated on [0,100]^2 grid

close all
[X1,Y1]=meshgrid(0:100);
X1=reshape(X1,length(0:100)^2,1);
Y1=reshape(Y1,length(0:100)^2,1);
load('Den1Sample.mat')
gm = gmdistribution(mu,sigma);
B = random(gm,m);
lbl=ones(size(B,1),1);
figure, scatter(B(:,1),-B(:,2)+100,[],lbl,'.')
       xlim([0,100])
       ylim([0,100])
       xlabel('x')
ylabel('y')
title('Density 1 sample')
PD=pdf(gm,[X1,Y1]);
PD=reshape(PD,101,101);
PD=PD./sum(sum(PD));
figure, imagesc(PD)
xlabel('x')
ylabel('y')
title('Density 1')
colorbar;