% implements algorithm 2 from affiliated paper with chosen density, in this
% case a patch of density 1 is recovered from a parabola manifold

load('Den1Sample.mat', 'mu','sigma')
load('cruveReconeEG.mat')

rad=20; %patch radius
kappa=0.05; %curvature of manifold
pcrd=[-10,-10,kappa/2*(10.^2+10.^2)]; %patch central coordinate

curveRecon