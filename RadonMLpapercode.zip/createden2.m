% create density 2 with sample size m
% density generated on [0,100]^2 grid

close all
[X1,Y1]=meshgrid(0:100);
X1=reshape(X1,length(0:100)^2,1);
Y1=reshape(Y1,length(0:100)^2,1);
B=[50*rand(round(m/5),2)+[5,25];50*rand(round(m/5),2)+[25,25];50*rand(round(m/5),2)+[45,25];50*rand(round(m/5),2)+[25,10];50*rand(round(m/5),2)+[25,40]];
lbl=ones(size(B,1),1);
figure, scatter(B(:,1),-B(:,2)+100,[],lbl,'.')
        xlim([0,100])
        ylim([0,100])
        xlabel('x')
ylabel('y')
title('Density 2 sample')

sz=50;
m=size(B,1);
PD=zeros(101);
pd1 = makedist('Uniform',5,5+sz);
pd2 = makedist('Uniform',25,25+sz);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*1000/m;
PD=PD+r1;
m=size(B,1);
pd1 = makedist('Uniform',25,25+sz);
pd2 = makedist('Uniform',25,25+sz);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*1000/m;
PD=PD+r1;
m=size(B,1);
pd1 = makedist('Uniform',45,45+sz);
pd2 = makedist('Uniform',25,25+sz);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*1000/m;
PD=PD+r1;
m=size(B,1);
pd1 = makedist('Uniform',25,25+sz);
pd2 = makedist('Uniform',10,10+sz);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*1000/m;
PD=PD+r1;
m=size(B,1);
pd1 = makedist('Uniform',25,25+sz);
pd2 = makedist('Uniform',40,40+sz);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*1000/m;
PD=PD+r1;
PD=PD./sum(sum(PD));
figure, imagesc(PD)
xlabel('x')
ylabel('y')
title('Density 2')
colorbar;