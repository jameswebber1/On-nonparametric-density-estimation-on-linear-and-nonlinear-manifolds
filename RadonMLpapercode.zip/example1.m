% must have IRtools codes in directory before running
% implements algorithm 1 from affiliated paper with chosen density, in this
% case density 3 is recovered

m=1000; %sample size
N=100; %grid size

[X1,Y1]=meshgrid(0:100); X1=reshape(X1,length(0:100)^2,1); Y1=reshape(Y1,length(0:100)^2,1);
r=4:20;
%R=CRadon1(r,X1,Y1,N+1); % create spherical Radon operator

s=-50:50; theta=0:pi/180:pi;
%R1=HRadon(s,theta,N); % create half space Radon operator
% don't need to create R and R1 everytime, could save and load in for
% increased speed 

createden3
%Den1Serv
densrecon1