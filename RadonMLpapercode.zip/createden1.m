% create random Gaussian mixture with sample size m
% density generated on [0,100]^2 grid

close all
[X1,Y1]=meshgrid(0:100);
X1=reshape(X1,length(0:100)^2,1);
Y1=reshape(Y1,length(0:100)^2,1);
mu=[20,20]+60*rand(100,2);
sigma=4*[1,10];
gm = gmdistribution(mu,sigma);
B = random(gm,m);
lbl=ones(size(B,1),1);
figure, scatter(B(:,1),-B(:,2)+100,[],lbl,'.')
        xlim([0,100])
        ylim([0,100])
        xlabel('x')
ylabel('y')
title('Gaussian mixture sample')
PD=pdf(gm,[X1,Y1]);
PD=reshape(PD,101,101);
PD=PD./sum(sum(PD));
figure, imagesc(PD)
xlabel('x')
ylabel('y')
title('Gaussian mixture')
colorbar;