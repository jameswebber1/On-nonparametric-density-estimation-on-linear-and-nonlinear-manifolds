% Reconstruct density, plot results and give least squares errors
% run after createden1,createden2,createden3,createden4

%close all
b=CRadond(r,X1,Y1,B,lbl);

options=[]; %options for IRhtv
options.RegParam='gcv';
options.inSolver='lsqr';
options.nonnegativity='on';
options.stopGCV='GCVvalues';

I=IRhtv(R,b,options);
I=I./sum(I);
figure, imagesc(reshape(I,101,101))
errSph=norm(I-reshape(PD,101^2,1))./norm(reshape(PD,101^2,1));
colorbar;
xlabel('x')
ylabel('y')
title('Spherical Radon reconstruction')

b=HRadond(s,theta,100,B,lbl);
I=IRhtv(R1,b,options);
I=I./sum(I);
figure, imagesc(reshape(I,101,101))
errHs=norm(I-reshape(PD,101^2,1))./norm(reshape(PD,101^2,1));
colorbar;
xlabel('x')
ylabel('y')
title('Half space Radon reconstruction')

err=[errSph,errHs]