% create density 3 with sample size m
% density generated on [0,100]^2 grid

close all
[X1,Y1]=meshgrid(0:100);
X1=reshape(X1,length(0:100)^2,1);
Y1=reshape(Y1,length(0:100)^2,1);
alpha=5*pi/4;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
r1=mvnrnd([0,0],3*[1,0;0,20],round(m./8));
r1=r1*rot;
r1=r1+[75,25];
B=r1;
alpha=3*pi/4;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
r1=mvnrnd([0,0],10*[1,0;0,10],round(m./8));
r1=r1*rot;
r1=r1+[75,75];
B=[B;r1];
alpha=0;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
r1=mvnrnd([0,0],10*[1,0;0,10],round(m./8));
r1=r1*rot;
r1=r1+[25,25];
B=[B;r1];
alpha=pi/4;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
r1=mvnrnd([0,0],10*[1,0;0,10],round(m./4));
r1=r1*rot;
r1=r1+[25,75];
B=[B;r1];
r1=[30*rand(round(m./4),2)+[25,25];30*rand(round(m./8),2)+[40,40]];
B=[B;r1];
lbl=ones(size(B,1),1);
figure, scatter(B(:,1),-B(:,2)+100,[],lbl,'.')
        xlim([0,100])
        ylim([0,100])
        xlabel('x')
ylabel('y')
title('Density 3 sample')
        
         
m=size(B,1);
PD=zeros(101);
alpha=5*pi/4;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
mu=[75,25];
sigma=rot'*3*[1,0;0,20]*rot;
gm = gmdistribution(mu,sigma);
r1=pdf(gm,[X1,Y1]);
r1=reshape(r1,101,101);
r1=r1*round(m./8)/m;
PD=PD+r1;
alpha=3*pi/4;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
mu=[75,75];
sigma=10*rot'*[1,0;0,10]*rot;
gm = gmdistribution(mu,sigma);
r1=pdf(gm,[X1,Y1]);
r1=reshape(r1,101,101);
r1=r1*round(m./8)/m;
PD=PD+r1;
alpha=0;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
mu=[25,25];
sigma=10*rot'*[1,0;0,10]*rot;
gm = gmdistribution(mu,sigma);
r1=pdf(gm,[X1,Y1]);
r1=reshape(r1,101,101);
r1=r1*round(m./8)/m;
PD=PD+r1;
alpha=pi/4;
rot=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
mu=[25,75];
sigma=10*rot'*[1,0;0,10]*rot;
gm = gmdistribution(mu,sigma);
r1=pdf(gm,[X1,Y1]);
r1=reshape(r1,101,101);
r1=r1*round(m./4)/m;
PD=PD+r1;
pd = makedist('Uniform',25,25+30);
r1=pdf(pd,[X1,Y1]);
r1=reshape(r1(:,1).*r1(:,2),101,101);
r1=r1*round(m./4)/m;
PD=PD+r1;
pd = makedist('Uniform',40,40+30);
r1=pdf(pd,[X1,Y1]);
r1=reshape(r1(:,1).*r1(:,2),101,101);
r1=r1*round(m./8)/m;
PD=PD+r1;
PD=PD./sum(sum(PD));
figure, imagesc(PD)
xlabel('x')
ylabel('y')
title('Density 3')
colorbar;