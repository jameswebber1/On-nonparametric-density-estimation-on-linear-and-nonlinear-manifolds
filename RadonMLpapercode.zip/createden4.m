% create density 4 with sample size m
% density generated on [0,100]^2 grid

close all
[X1,Y1]=meshgrid(0:100);
X1=reshape(X1,length(0:100)^2,1);
Y1=reshape(Y1,length(0:100)^2,1);
B=[10*randn(round(m*2000/8500),2)+35;10*randn(round(m*1000/8500),2)+65];
        pd = makedist('Exponential',20);
        r1=random(pd,[round(m*2000/8500),2]);
        B=[B;r1];
        pd = makedist('Gamma',5,10);
        r1=random(pd,[round(m*2000/8500),2]);
        r1=r1+[0,50];
        B=[B;r1];
        r1=20*rand(round(m*500/8500),2)+[75,25];
        B=[B;r1];
        r1=20*rand(round(m*500/8500),2)+[60,25];
        B=[B;r1];
        r1=20*rand(round(m*500/8500),2)+[45,25];
        B=[B;r1];
        lbl=ones(size(B,1),1);
figure, scatter(B(:,1),-B(:,2)+100,[],lbl,'.')
        xlim([0,100])
        ylim([0,100])
        xlabel('x')
ylabel('y')
title('Density 4 sample')
       
        m=size(B,1);
        PD=zeros(101);
        pd = makedist('Exponential',20);
        r1=pdf(pd,[X1,Y1]);
r1=reshape(r1(:,1).*r1(:,2),101,101);
r1=r1*round(m*2000/8500)/m;
PD=PD+r1;
pd = makedist('Gamma',5,10);
r1=pdf(pd,[X1,Y1-50]);
r1=reshape(r1(:,1).*r1(:,2),101,101);
r1=r1*round(m*2000/8500)/m;
PD=PD+r1;
pd1 = makedist('Uniform',75,75+20);
pd2 = makedist('Uniform',25,25+20);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*round(m*500/8500)/m;
PD=PD+r1;
pd1 = makedist('Uniform',60,60+20);
pd2 = makedist('Uniform',25,25+20);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*round(m*500/8500)/m;
PD=PD+r1;
pd1 = makedist('Uniform',45,45+20);
pd2 = makedist('Uniform',25,25+20);
r1=pdf(pd1,[X1,Y1]);
r2=pdf(pd2,[X1,Y1]);
r1=reshape(r1(:,1).*r2(:,2),101,101);
r1=r1*round(m*500/8500)/m;
PD=PD+r1;
mu=[35,35];
sigma=[100,0;0,100];
gm = gmdistribution(mu,sigma);
r1=pdf(gm,[X1,Y1]);
r1=reshape(r1,101,101);
r1=r1*round(m*2000/8500)/m;
PD=PD+r1;
mu=[65,65];
sigma=[100,0;0,100];
gm = gmdistribution(mu,sigma);
r1=pdf(gm,[X1,Y1]);
r1=reshape(r1,101,101);
r1=r1*round(m*1000/8500)/m;
PD=PD+r1;
PD=PD./sum(sum(PD));
figure, imagesc(PD)
xlabel('x')
ylabel('y')
title('Density 4')
colorbar;