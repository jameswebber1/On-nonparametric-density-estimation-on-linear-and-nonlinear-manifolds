function b = CRadond(r,x,y,B,lbl)
% Generates spherical Radon transform data form point cloud

% inputs:
% 1) r (1Xn vector) is set of sphere radii, r=4:20
% 2) (x,y) (a pair of 1Xm vectors) are the coordinates of the sphere centers, e.g.,
% [x,y]=meshgrid(0:100); x=reshape(x,length(0:100)^2,1); y=reshape(y,length(0:100)^2,1);
% 3) B (nsamples X ndimensions matrix) is point cloud
% 4) lbl (nsamples X 1 vector) is vector of labels for each sample of B

% outputs
% 1) b is spherical Radon transform data

n=length(x);
m=length(r);
b=zeros(n*m,1);
u1=B(:,1);
u2=B(:,2);
N1=length(u1);
for j=1:m
    j1=(j-1)*n;
    s=r(j).^2;
for i=1:n
    x1=(u1-x(i)).^2;
    y1=(u2-y(i)).^2;
    v=(x1+y1)<s;
    v=reshape(v,1,N1);
    v=v*lbl;
    b(j1+i)=v;
end
b(isnan(b))=1/2;
end



end

