function [R] = CRadon1(r,x,y,N)
% Generate spherical Radon operator

% inputs:
% 1) r (1Xn vector) is set of sphere radii, r=4:20
% 2) (x,y) (a pair of 1Xm vectors) are the coordinates of the sphere centers, e.g.,
% [x,y]=meshgrid(0:100); x=reshape(x,length(0:100)^2,1); y=reshape(y,length(0:100)^2,1);
% 3) N (positive integer) is grid size, e.g., N=101

% outputs
% 1) R is sparse matrix (size (nXm)XN^2) which is the discrete form of the
% spherical Radon transform

cf1=50; 
cf2=50;
crf=50;
p1=(cf1-crf)+crf/N:2*crf/N:(cf1+crf);
p2=(cf2-crf)+crf/N:2*crf/N:(cf2+crf);
[X,Y] = meshgrid(p1,p2); X = reshape(X,1,N^2); Y = reshape(Y,1,N^2);
R=[];
n=length(x);
m=length(r);
N1=N^2;
for j=1:m
    M=zeros(n,N1);
    r1=r(j).^2;
for i=1:n
    c1=x(i);
    c2=y(i);
    v=((X-c1).^2+(Y-c2).^2)<r1;
    v=reshape(v,1,N1);
    M(i,v)=1;
end
M=sparse(M);
R=[R;M];
end


end

